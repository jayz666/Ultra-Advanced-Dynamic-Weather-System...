
local currentWeather = nil
local targetState = {}
local interp = nil -- {startTime, duration, from = {}, to = {}}
local lastApply = 0

local function lerp(a, b, t)
    return a + (b - a) * t
end

local function applyImmediate(state)
    local wt = state.weatherType or "CLEAR"

    if wt == "RAIN" then
        SetOverrideWeather("RAIN")
        SetWeatherTypeNowPersist("RAIN")
        SetRainLevel(state.intensity or 0.5)
        SetWindSpeed(state.windSpeed or (5.0 + (state.intensity or 0.5) * 5.0))
    elseif wt == "STORM" then
        SetOverrideWeather("THUNDER")
        SetWeatherTypeNowPersist("THUNDER")
        SetRainLevel(1.0)
        SetWindSpeed(state.windSpeed or 10.0)
        SetWindDirection(state.windDirection or math.random(-90,90))
    elseif wt == "SNOW" then
        SetOverrideWeather("XMAS")
        SetWeatherTypeNowPersist("XMAS")
        SetRainLevel(state.intensity or 0.0)
        SetWindSpeed(state.windSpeed or 3.0)
        SetForceVehicleTrails(true)
        SetForcePedFootstepsTracks(true)
    else
        ClearOverrideWeather()
        ClearWeatherTypePersist()
        SetWeatherTypeNowPersist("CLEAR")
        SetRainLevel(0.0)
        SetWindSpeed(1.0)
        SetForceVehicleTrails(false)
        SetForcePedFootstepsTracks(false)
    end

    -- handle blackout visual state
    if state.powerOn == false then
        SetArtificialLightsState(true)
        SetArtificialLightsStateAffectsVehicles(true)
    else
        SetArtificialLightsState(false)
        SetArtificialLightsStateAffectsVehicles(false)
    end

    currentWeather = state
    lastApply = GetGameTimer()
end

RegisterNetEvent('qb-advancedweather-ultra:client:ApplyWeather', function(data)
    -- support interpolation payloads: data.interp = {duration=ms}
    if data == nil then return end

    -- if no interpolation requested, apply immediately
    if not data.interp or type(data.interp.duration) ~= 'number' or data.interp.duration <= 0 then
        interp = nil
        targetState = data
        applyImmediate(data)
        return
    end

    -- build interpolation
    local duration = math.max(100, data.interp.duration)
    interp = {
        startTime = GetGameTimer(),
        duration = duration,
        from = {
            weatherType = currentWeather and currentWeather.weatherType or "CLEAR",
            intensity = currentWeather and currentWeather.intensity or 0.0,
            windSpeed = currentWeather and currentWeather.windSpeed or 1.0,
            windDirection = currentWeather and currentWeather.windDirection or 0,
            powerOn = currentWeather and currentWeather.powerOn
        },
        to = {
            weatherType = data.weatherType or "CLEAR",
            intensity = data.intensity or 0.0,
            windSpeed = data.windSpeed or (5.0 + (data.intensity or 0.0) * 5.0),
            windDirection = data.windDirection or math.random(-90,90),
            powerOn = data.powerOn
        }
    }

    targetState = data
end)

-- interpolation tick
CreateThread(function()
    while true do
        Wait(100) -- 10Hz client-side interpolation
        if interp then
            local now = GetGameTimer()
            local t = math.min(1.0, (now - interp.startTime) / interp.duration)

            -- If weatherType changes across categories, switch override when reaching 50% to avoid abrupt resets
            if t >= 0.5 and currentWeather and currentWeather.weatherType ~= interp.to.weatherType then
                -- change persistent type halfway through
                if interp.to.weatherType == "CLEAR" then
                    ClearOverrideWeather()
                    ClearWeatherTypePersist()
                    SetWeatherTypeNowPersist("CLEAR")
                elseif interp.to.weatherType == "RAIN" then
                    SetOverrideWeather("RAIN")
                    SetWeatherTypeNowPersist("RAIN")
                elseif interp.to.weatherType == "STORM" then
                    SetOverrideWeather("THUNDER")
                    SetWeatherTypeNowPersist("THUNDER")
                elseif interp.to.weatherType == "SNOW" then
                    SetOverrideWeather("XMAS")
                    SetWeatherTypeNowPersist("XMAS")
                end
            end

            local intensity = lerp(interp.from.intensity, interp.to.intensity, t)
            local wind = lerp(interp.from.windSpeed, interp.to.windSpeed, t)
            local direction = lerp(interp.from.windDirection, interp.to.windDirection, t)

            SetRainLevel(intensity)
            SetWindSpeed(wind)
            SetWindDirection(math.floor(direction))

            -- handle blackout interpolation (boolean -> immediate change at t>=0.5)
            if interp.from.powerOn ~= interp.to.powerOn then
                if t >= 0.5 then
                    if interp.to.powerOn == false then
                        SetArtificialLightsState(true)
                        SetArtificialLightsStateAffectsVehicles(true)
                    else
                        SetArtificialLightsState(false)
                        SetArtificialLightsStateAffectsVehicles(false)
                    end
                end
            end

            if t >= 1.0 then
                -- finish
                currentWeather = targetState
                interp = nil
            end
        end
    end
end)

-- initial sync after player loads
CreateThread(function()
    Wait(5000)
    TriggerServerEvent("qb-advancedweather-ultra:server:RequestSync")
end)
