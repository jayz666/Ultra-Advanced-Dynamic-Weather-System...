
-- Umbrella support example.
-- Add a usable item in qb-core named 'umbrella'
-- and trigger event: TriggerClientEvent('qb-advancedweather-ultra:client:UseUmbrella', src)

local umbrellaProp = nil
local umbrellaOn = false

local function removeUmbrella()
    if umbrellaProp and DoesEntityExist(umbrellaProp) then
        DeleteEntity(umbrellaProp)
    end
    umbrellaProp = nil
    umbrellaOn = false
end

RegisterNetEvent("qb-advancedweather-ultra:client:UseUmbrella", function()
    local ped = PlayerPedId()

    if umbrellaOn then
        removeUmbrella()
        return
    end

    local model = `p_amb_brolly_01`
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end

    umbrellaProp = CreateObject(model, 0.0, 0.0, 0.0, true, true, false)
    AttachEntityToEntity(umbrellaProp, ped, GetPedBoneIndex(ped, 57005), 0.13, 0.0, 0.0, 80.0, 20.0, 180.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(model)
    umbrellaOn = true
end)

AddEventHandler("onResourceStop", function(res)
    if res == GetCurrentResourceName() then
        removeUmbrella()
    end
end)
