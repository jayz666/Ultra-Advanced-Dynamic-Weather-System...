
-- Weather Channel UI with sound and configurable notifications
-- Triggered via command or server NewsFlash

local function playWeatherSound()
    if Config.WeatherChannel and Config.WeatherChannel.sound and Config.WeatherChannel.sound.enable then
        -- play a short chime using frontend soundset
        PlaySoundFrontend(-1, Config.WeatherChannel.sound.name or "Menu_Accept", Config.WeatherChannel.soundset or "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
end

local function showWeatherTicker(title, body)
    if Config.WeatherChannel and Config.WeatherChannel.useTicker then
        BeginTextCommandThefeedPost("STRING")
        AddTextComponentSubstringPlayerName(string.format("~y~%s~s~\n%s", title or Config.WeatherNewsPrefix, body or ""))
        EndTextCommandThefeedPostTicker(false, true)
    else
        -- fallback to simple notification
        SetNotificationTextEntry("STRING")
        AddTextComponentString((title and (title .. " - ") or "") .. (body or ""))
        DrawNotification(false, true)
    end
end

RegisterCommand("weathertv", function()
    playWeatherSound()
    showWeatherTicker("Weather Channel Live", "Expect dynamic conditions. Check your phone app or listen to radio for alerts.")
end, false)

RegisterKeyMapping("weathertv", "Toggle Weather TV News", "keyboard", "F8")

-- allow server to trigger enhanced news flash with sound
RegisterNetEvent("qb-advancedweather-ultra:client:NewsFlashEnhanced", function(title, message)
    playWeatherSound()
    showWeatherTicker(title or Config.WeatherNewsPrefix, message)
end)

-- allow direct client testing via /weathertest (shows enhanced UI and sound)
RegisterCommand('weathertest', function()
    playWeatherSound()
    showWeatherTicker("WEATHER TEST", "This is a test alert. Storm activity: see dispatch notes.")
end, false)

RegisterKeyMapping('weathertest', 'Trigger Weather Test Alert', 'keyboard', 'F9')
