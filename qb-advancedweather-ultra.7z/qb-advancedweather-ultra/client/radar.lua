
-- Minimal "radar" drawn on screen (no NUI) to visualise storms/hurricanes for PD/dispatch.

local radarEnabled = false

RegisterCommand("weatherradar", function()
    radarEnabled = not radarEnabled
end, false)

RegisterKeyMapping("weatherradar", "Toggle Weather Radar", "keyboard", "F7")

RegisterNetEvent("qb-advancedweather-ultra:client:RadarData", function(systems, hurricanes)
    -- not used yet but kept for possible expansion
end)

CreateThread(function()
    while true do
        Wait(0)
        if radarEnabled then
            -- simple box bottom-right
            local x, y = 0.82, 0.75
            local w, h = 0.16, 0.20

            DrawRect(x, y, w, h, 0, 0, 0, 150)
            SetTextFont(0)
            SetTextScale(0.3, 0.3)
            SetTextColour(255,255,255,255)
            SetTextCentre(1)
            SetTextEntry("STRING")
            AddTextComponentString("WEATHER RADAR\nStorm activity: see dispatch notes.")
            DrawText(x, y - 0.08)
        end
    end
end)
