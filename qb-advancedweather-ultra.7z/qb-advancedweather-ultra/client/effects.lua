
local currentSeason = "summer"
local zonePower = {}

RegisterNetEvent("qb-advancedweather-ultra:client:SeasonUpdate", function(season)
    currentSeason = season
end)

RegisterNetEvent("qb-advancedweather-ultra:client:GridUpdate", function(zone, state)
    zonePower[zone] = state
end)

local function playWeatherSound()
    if Config.WeatherChannel and Config.WeatherChannel.sound and Config.WeatherChannel.sound.enable then
        PlaySoundFrontend(-1, Config.WeatherChannel.sound.name or "Menu_Accept", Config.WeatherChannel.soundset or "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
end

RegisterNetEvent("qb-advancedweather-ultra:client:NewsFlash", function(message)
    -- legacy lightweight news flash (no title)
    playWeatherSound()
    if Config.WeatherChannel and Config.WeatherChannel.enhanced then
        -- delegate to enhanced event handler in tv.lua
        TriggerEvent("qb-advancedweather-ultra:client:NewsFlashEnhanced", Config.WeatherNewsPrefix, message)
    else
        SetNotificationTextEntry("STRING")
        AddTextComponentString("~y~" .. Config.WeatherNewsPrefix .. "~s~ " .. message)
        DrawNotification(false, true)
    end
end)

-- Simple handling tweaks / puddles / traction changes
CreateThread(function()
    while true do
        Wait(2000)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)

        if veh ~= 0 then
            local _, wHash = GetWeatherTypeTransition()
            -- crude check of current weather
            if wHash == GetHashKey("RAIN") or wHash == GetHashKey("THUNDER") then
                SetVehicleReduceGrip(veh, true)
            elseif wHash == GetHashKey("XMAS") then
                -- snow: more slippery
                SetVehicleReduceGrip(veh, true)
            else
                SetVehicleReduceGrip(veh, false)
            end
        end
    end
end)
