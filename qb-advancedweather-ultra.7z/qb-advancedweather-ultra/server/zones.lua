
-- Super simple zone logic; you can replace with PolyZone or other libs.

exports("GetZoneFromCoords", function(coords)
    local x, y = coords.x, coords.y

    -- rough split by X for demo / test
    if x > 1000.0 then
        return "paleto"
    elseif x < -500.0 then
        return "sandy"
    else
        return "city"
    end
end)
