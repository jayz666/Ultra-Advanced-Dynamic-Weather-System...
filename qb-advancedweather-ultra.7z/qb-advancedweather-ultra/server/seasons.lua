
WeatherState = WeatherState or {
    season = "summer",
    systems = {},
    hurricanes = {}
}

CreateThread(function()
    local seasons = {"summer","autumn","winter","spring"}
    local index = 1

    while true do
        Wait(3600000) -- change season every in-game hour (tune for your server)
        index = index + 1
        if index > #seasons then index = 1 end

        WeatherState.season = seasons[index]
        TriggerClientEvent("qb-advancedweather-ultra:client:SeasonUpdate", -1, WeatherState.season)
        TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
            "Season has changed to " .. seasons[index] .. ".")
    end
end)
