
local QBCore = exports['qb-core']:GetCoreObject()

-- Simple HAARP-style manual controls.
-- You can call these from a mission script / heist script.

RegisterNetEvent("qb-advancedweather-ultra:server:ForceStorm", function(zone)
    local src = source
    zone = zone or "city"

    TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
        "Anomalous readings detected above " .. zone .. ". Sudden storm activity expected.")
    -- easiest way: temporarily boost storm chance via a fake system
    table.insert(WeatherState.systems, {
        id = math.random(100000,999999),
        x = 0.0,
        y = 0.0,
        direction = math.random(0,360),
        speed = 0.0,
        strength = 1.0,
        createdAt = os.time(),
        type = "storm"
    })
end)

RegisterNetEvent("qb-advancedweather-ultra:server:ForceClear", function(zone)
    local src = source
    TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
        "Skies clearing rapidly. Atmospheric interference dropping.")
    WeatherState.systems = {}
    WeatherState.hurricanes = {}
end)

QBCore.Commands.Add("haarpstorm", "Trigger experimental storm (dev tool)", {{name="zone", help="city/sandy/paleto"}}, false, function(source, args)
    local zone = args[1] or "city"
    TriggerEvent("qb-advancedweather-ultra:server:ForceStorm", zone)
end, "god")

QBCore.Commands.Add("haarpclear", "Clear all storms (dev tool)", {}, false, function(source, args)
    TriggerEvent("qb-advancedweather-ultra:server:ForceClear")
end, "god")
