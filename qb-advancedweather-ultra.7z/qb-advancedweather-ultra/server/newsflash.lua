
-- Periodic generic weather news + server broadcast handler

local function broadcastMessage(msg, emergency)
    local prefix = Config.WeatherChannel and Config.WeatherChannel.serverPrefix or Config.WeatherNewsPrefix
    local payload = prefix .. " " .. (msg or "")

    if Config.WeatherChannel and Config.WeatherChannel.enabled and Config.WeatherChannel.enhanced then
        TriggerClientEvent('qb-advancedweather-ultra:client:NewsFlashEnhanced', -1, payload, emergency or false)
    else
        TriggerClientEvent('qb-advancedweather-ultra:client:NewsFlash', -1, payload)
    end
end

-- Periodic generic weather news
CreateThread(function()
    while true do
        Wait(Config.NewsBroadcastInterval * 1000)

        local msg = "Stable conditions across the state. Localised showers and storms possible."
        broadcastMessage(msg, false)
    end
end)

-- Server event to broadcast a weather news message (can be called by other server code)
RegisterNetEvent('qb-advancedweather-ultra:server:BroadcastNews', function(msg, emergency)
    if type(msg) ~= 'string' then return end
    broadcastMessage(msg, emergency)
end)

-- Simple console/command for admins to send WeatherChannel messages
RegisterCommand('weathernews', function(source, args, raw)
    local msg = table.concat(args, ' ')
    if msg == '' then
        if source ~= 0 then
            local _src = source
            local p = QBCore.Functions.GetPlayer(_src)
            if p then
                TriggerClientEvent('QBCore:Notify', _src, 'Usage: /weathernews <message>', 'error')
            end
        end
        return
    end

    -- allow console or server-side callers; for players, require boss police job (customise as needed)
    if source == 0 or (source > 0 and (function()
        local p = QBCore.Functions.GetPlayer(source)
        if not p then return false end
        local job = p.PlayerData.job
        if not job then return false end
        return job.isboss or job.name == 'police'
    end)()) then
        broadcastMessage(msg, true)
    else
        local _src = source
        local p = QBCore.Functions.GetPlayer(_src)
        if p then
            TriggerClientEvent('QBCore:Notify', _src, 'Insufficient permissions to broadcast weather news.', 'error')
        end
    end
end, false)

-- Quick test command for admins/console to send a canned weather test message
RegisterCommand('weathertest', function(source, args, raw)
    local testMsg = "Storm activity: see dispatch notes. This is a test broadcast from Weather System."

    if source == 0 or (source > 0 and (function()
        local p = QBCore.Functions.GetPlayer(source)
        if not p then return false end
        local job = p.PlayerData.job
        if not job then return false end
        return job.isboss or job.name == 'police'
    end)()) then
        broadcastMessage(testMsg, true)
    else
        local _src = source
        local p = QBCore.Functions.GetPlayer(_src)
        if p then
            TriggerClientEvent('QBCore:Notify', _src, 'Insufficient permissions to run /weathertest', 'error')
        end
    end
end, false)