
local QBCore = exports['qb-core']:GetCoreObject()

ZonePower = ZonePower or {}

local function randomFloat()
    return math.random()
end

RegisterNetEvent("qb-advancedweather-ultra:server:GridTick", function()
    -- This event is called from weather_core once per minute
    for _, zone in ipairs(Config.Grid.zones) do
        -- if already in outage, skip
        if ZonePower[zone] == false then
            goto continue
        end

        local failureChance = Config.Grid.baseFailureChance

        -- check any player in zone & their weather
        local severe = false
        for _, src in pairs(QBCore.Functions.GetPlayers()) do
            local pdata = PlayersWeather and PlayersWeather[src]
            if pdata and pdata.zone == zone then
                if pdata.weatherType == "STORM" then
                    failureChance = failureChance + Config.Grid.stormFailureBonus
                    severe = true
                end
                if pdata.hurricane then
                    failureChance = failureChance + Config.Grid.hurricaneFailureBonus
                    severe = true
                end
            end
        end

        if randomFloat() < failureChance then
            ZonePower[zone] = false
            local duration = math.random(Config.Grid.outageDuration.min, Config.Grid.outageDuration.max)

            TriggerClientEvent("qb-advancedweather-ultra:client:GridUpdate", -1, zone, false)

            local msg = "Power outage reported in " .. zone .. ". "
            if severe then
                msg = msg .. "Cause: severe weather conditions."
            else
                msg = msg .. "Cause under investigation."
            end

            TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1, msg)

            -- schedule restore
            CreateThread(function()
                Wait(duration * 1000)
                ZonePower[zone] = true
                TriggerClientEvent("qb-advancedweather-ultra:client:GridUpdate", -1, zone, true)
                TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
                    "Power has been restored in " .. zone .. ".")
            end)
        end

        ::continue::
    end
end)

-- Command hook example for utilities job to restore power manually
QBCore.Commands.Add("fixpower", "Attempt to restore power in your zone (utilities job)", {}, false, function(source)
    local src = source
    local ped = GetPlayerPed(src)
    if not DoesEntityExist(ped) then return end
    local coords = GetEntityCoords(ped)

    local zone = exports['qb-advancedweather-ultra']:GetZoneFromCoords(coords)
    if ZonePower[zone] ~= false then
        TriggerClientEvent("QBCore:Notify", src, "Power grid in this zone is already stable.", "error")
        return
    end

    -- here you can add job checks, items, mini-games, etc.
    ZonePower[zone] = true
    TriggerClientEvent("qb-advancedweather-ultra:client:GridUpdate", -1, zone, true)
    TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
        "Utilities crews have restored power in " .. zone .. ".")
end, "admin")
