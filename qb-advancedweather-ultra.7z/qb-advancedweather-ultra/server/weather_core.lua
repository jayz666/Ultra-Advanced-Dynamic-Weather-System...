
local QBCore = exports['qb-core']:GetCoreObject()

WeatherState = WeatherState or {
    season = "summer",
    systems = WeatherState and WeatherState.systems or {},
    hurricanes = WeatherState and WeatherState.hurricanes or {},
    -- timeOfDay is a float 0-24 representing current in-world hour
    timeOfDay = WeatherState and WeatherState.timeOfDay or Config.DayNight.defaultStartHour or 12
}

PlayersWeather = PlayersWeather or {}
ZonePower = ZonePower or {}

-- initial grid state (all powered)
CreateThread(function()
    if not next(ZonePower) then
        for _, zone in ipairs(Config.Grid.zones) do
            ZonePower[zone] = true
        end
    end
end)

local function SyncPlayerWeather(src)
    local ped = GetPlayerPed(src)
    if not DoesEntityExist(ped) then return end

    local coords = GetEntityCoords(ped)
    if not coords then
        print("qb-advancedweather-ultra: SyncPlayerWeather - missing coords for src", src)
        return
    end

    -- safely call exports (protect against nil/misconfigured exports)
    local ok, zone = pcall(function()
        return exports['qb-advancedweather-ultra']:GetZoneFromCoords(coords)
    end)
    if not ok or not zone then
        print("qb-advancedweather-ultra: SyncPlayerWeather - GetZoneFromCoords failed for src", src)
        zone = "city" -- fallback
    end

    local ok2, data = pcall(function()
        return exports['qb-advancedweather-ultra']:CalculateWeatherForZone(zone, coords)
    end)
    if not ok2 or not data then
        print("qb-advancedweather-ultra: SyncPlayerWeather - CalculateWeatherForZone failed for src", src)
        data = { season = WeatherState.season or "summer", weather = "CLEAR" }
    end

    data.zone = zone
    data.powerOn = ZonePower[zone] ~= false

    -- include server timeOfDay so clients can adjust lighting/day-night if desired
    data.timeOfDay = WeatherState.timeOfDay

    PlayersWeather[src] = data
    TriggerClientEvent('qb-advancedweather-ultra:client:ApplyWeather', src, data)
end

RegisterNetEvent("qb-advancedweather-ultra:server:RequestSync", function()
    local src = source
    SyncPlayerWeather(src)
end)

-- server time progression: advance WeatherState.timeOfDay based on configured day/night lengths
CreateThread(function()
    local lastTime = os.time()
    while true do
        Wait(60000) -- global tick every minute

        local now = os.time()
        local elapsed = math.max(0, now - lastTime)
        lastTime = now

        -- advance timeOfDay according to elapsed real seconds and configured cycle
        local dayLen = (Config.DayNight and Config.DayNight.dayLength) or (18 * 60)
        local nightLen = (Config.DayNight and Config.DayNight.nightLength) or (6 * 60)
        local cycleSeconds = dayLen + nightLen

        if cycleSeconds > 0 then
            local hoursAdvance = 24 * (elapsed / cycleSeconds)
            -- ensure WeatherState and timeOfDay are initialized and numeric
            if not WeatherState then WeatherState = {} end
            if type(WeatherState.timeOfDay) ~= 'number' then
                WeatherState.timeOfDay = tonumber(Config.DayNight and Config.DayNight.defaultStartHour) or 12
            end
            WeatherState.timeOfDay = (WeatherState.timeOfDay + hoursAdvance) % 24
        end

        for _, src in pairs(QBCore.Functions.GetPlayers()) do
            SyncPlayerWeather(src)
        end

        -- also tick grid logic
        TriggerEvent("qb-advancedweather-ultra:server:GridTick")

        -- Optionally send periodic automated bulletins via newsflash (configured interval in config.lua)
        -- This keeps periodic weather summaries tied to the same tick loop and avoids duplicate threads
    end
end)

-- EXPORTS

exports("GetPlayerWeather", function(src)
    return PlayersWeather[src]
end)

exports("IsZonePowered", function(zone)
    return ZonePower[zone] ~= false
end)

exports("SetZonePower", function(zone, state)
    ZonePower[zone] = state and true or false
    TriggerClientEvent("qb-advancedweather-ultra:client:GridUpdate", -1, zone, ZonePower[zone])
end)

-- Persistence: save/load WeatherState to a resource file
local PERSIST_FILE = 'weather_state.json'

local function validateState(state)
    if type(state) ~= 'table' then return false end
    if type(state.season) ~= 'string' then return false end
    if type(state.systems) ~= 'table' then return false end
    if type(state.hurricanes) ~= 'table' then return false end
    return true
end

local function saveWeatherState()
    local ok, encoded = pcall(function() return json.encode(WeatherState) end)
    if not ok or not encoded then
        print('qb-advancedweather-ultra: saveWeatherState - encode failed')
        return false
    end

    local resource = GetCurrentResourceName()
    local pathInfo = ('%s/%s'):format(resource, PERSIST_FILE)
    print(('qb-advancedweather-ultra: saveWeatherState - writing to %s'):format(pathInfo))

    local resOk, err = SaveResourceFile(resource, PERSIST_FILE, encoded, -1)
    if not resOk then
        print('qb-advancedweather-ultra: saveWeatherState - SaveResourceFile failed', err)
        return false
    end

    print('qb-advancedweather-ultra: WeatherState saved')
    return true
end

local function loadWeatherState()
    local resource = GetCurrentResourceName()
    local pathInfo = ('%s/%s'):format(resource, PERSIST_FILE)
    print(('qb-advancedweather-ultra: loadWeatherState - attempting to read %s'):format(pathInfo))

    local data = LoadResourceFile(resource, PERSIST_FILE)
    if not data or data == '' then
        print(('qb-advancedweather-ultra: no persisted weather state found at %s'):format(pathInfo))
        return false
    end

    local ok, decoded = pcall(function() return json.decode(data) end)
    if not ok or not decoded then
        print('qb-advancedweather-ultra: loadWeatherState - decode failed')
        print('qb-advancedweather-ultra: raw data preview (first 512 chars):', tostring(data):sub(1,512))
        return false
    end

    if not validateState(decoded) then
        print('qb-advancedweather-ultra: loadWeatherState - validation failed')
        return false
    end

    WeatherState = decoded
    print(('qb-advancedweather-ultra: WeatherState loaded from %s'):format(pathInfo))
    return true
end

-- Auto-save thread (every 5 minutes)
CreateThread(function()
    while true do
        Wait(5 * 60 * 1000)
        local ok, err = pcall(saveWeatherState)
        if not ok then
            print('qb-advancedweather-ultra: autosave failed', err)
        end
    end
end)

-- Commands to force-save / force-load
QBCore.Commands.Add("weathersave", "Save weather state to disk", {}, false, function(source, args)
    if source ~= 0 then
        local Player = QBCore.Functions.GetPlayer(source)
        local allowed = false

        -- Debug: print player's job info when permission checks fail
        if Player and Player.PlayerData and Player.PlayerData.job then
            local job = Player.PlayerData.job
            print(('qb-advancedweather-ultra: weathersave - invoking player %s, job=%s, isboss=%s'):format(source, tostring(job.name), tostring(job.isboss)))
        else
            print(('qb-advancedweather-ultra: weathersave - invoking player %s has no job data'):format(source))
        end

        -- allow explicit admin job or any job boss (isboss)
        if Player and Player.PlayerData and Player.PlayerData.job and (Player.PlayerData.job.name == 'admin' or Player.PlayerData.job.isboss) then
            allowed = true
        end
        -- If QBCore provides a HasPermission helper, prefer it (safe call)
        local ok, hasPerm = pcall(function() return QBCore.Functions.HasPermission and QBCore.Functions.HasPermission(source, "admin") end)
        if ok and hasPerm then allowed = true end
        if not allowed then
            TriggerClientEvent('QBCore:Notify', source, 'You are not allowed to do that', 'error')
            return
        end
    end

    if saveWeatherState() then
        if source == 0 then
            print('Weather state saved by console')
        else
            TriggerClientEvent('QBCore:Notify', source, 'Weather state saved', 'success')
        end
    else
        if source == 0 then
            print('Weather state save failed')
        else
            TriggerClientEvent('QBCore:Notify', source, 'Weather state save failed', 'error')
        end
    end
end)

QBCore.Commands.Add("weatherload", "Load weather state from disk", {}, false, function(source, args)
    if source ~= 0 then
        local Player = QBCore.Functions.GetPlayer(source)
        local allowed = false

        -- Debug: print player's job info when permission checks fail
        if Player and Player.PlayerData and Player.PlayerData.job then
            local job = Player.PlayerData.job
            print(('qb-advancedweather-ultra: weatherload - invoking player %s, job=%s, isboss=%s'):format(source, tostring(job.name), tostring(job.isboss)))
        else
            print(('qb-advancedweather-ultra: weatherload - invoking player %s has no job data'):format(source))
        end

        if Player and Player.PlayerData and Player.PlayerData.job and (Player.PlayerData.job.name == 'admin' or Player.PlayerData.job.isboss) then
            allowed = true
        end
        local ok, hasPerm = pcall(function() return QBCore.Functions.HasPermission and QBCore.Functions.HasPermission(source, "admin") end)
        if ok and hasPerm then allowed = true end
        if not allowed then
            TriggerClientEvent('QBCore:Notify', source, 'You are not allowed to do that', 'error')
            return
        end
    end

    if loadWeatherState() then
        -- After loading, sync all players
        for _, src in pairs(QBCore.Functions.GetPlayers()) do
            SyncPlayerWeather(src)
        end

        if source == 0 then
            print('Weather state loaded by console')
        else
            TriggerClientEvent('QBCore:Notify', source, 'Weather state loaded', 'success')
        end
    else
        if source == 0 then
            print('Weather state load failed')
        else
            TriggerClientEvent('QBCore:Notify', source, 'Weather state load failed', 'error')
        end
    end
end)

-- Attempt to load persisted state on resource start
CreateThread(function()
    Wait(1000) -- let other init finish
    local ok, err = pcall(loadWeatherState)
    if not ok then
        print('qb-advancedweather-ultra: initial loadWeatherState failed', err)
    end
end)

