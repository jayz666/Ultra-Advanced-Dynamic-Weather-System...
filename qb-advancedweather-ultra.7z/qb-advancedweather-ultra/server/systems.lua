
-- Weather systems & hurricanes

WeatherState = WeatherState or {
    season = "summer",
    systems = {},
    hurricanes = {}
}

local function generateStorm()
    return {
        id = math.random(100000,999999),
        x = math.random(-4000, 4000),
        y = math.random(-4000, 4000),
        direction = math.random(0, 360),
        speed = math.random(5, 20),
        strength = math.random(),
        createdAt = os.time(),
        type = "storm"
    }
end

local function generateHurricane()
    local lifespan = math.random(Config.Hurricanes.lifespan.min, Config.Hurricanes.lifespan.max)
    local minS = tonumber(Config.Hurricanes.minStrength) or 0.1
    local maxS = tonumber(Config.Hurricanes.maxStrength) or 1.0
    local strength = minS + math.random() * math.max(0, (maxS - minS))
    return {
        id = math.random(100000,999999),
        x = math.random(-5000, 5000),
        y = math.random(-5000, 5000),
        direction = math.random(0, 360),
        speed = math.random(10, 25),
        strength = strength,
        createdAt = os.time(),
        expiresAt = os.time() + lifespan,
        type = "hurricane"
    }
end

-- Spawn & lifecycle thread (low frequency)
CreateThread(function()
    while true do
        Wait(300000) -- every 5 minutes: spawning / lifecycle management

        -- spawn normal storms
        if math.random() < 0.25 then
            table.insert(WeatherState.systems, generateStorm())
        end

        -- hurricanes (only in certain seasons and if enabled)
        if Config.Hurricanes.enabled then
            local season = WeatherState.season or "summer"
            if season == "summer" or season == "autumn" then
                if math.random() < Config.Hurricanes.baseChance then
                    table.insert(WeatherState.hurricanes, generateHurricane())
                    TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
                        "Tropical storm has formed offshore. Hurricane conditions possible.")
                end
            end
        end

        -- simple lifetime cleanup (positions updated in fast tick)
        local now = os.time()

        for i = #WeatherState.systems, 1, -1 do
            local storm = WeatherState.systems[i]
            if (now - storm.createdAt) > 3600 then
                table.remove(WeatherState.systems, i)
            end
        end

        for i = #WeatherState.hurricanes, 1, -1 do
            local h = WeatherState.hurricanes[i]
            if now >= h.expiresAt then
                table.remove(WeatherState.hurricanes, i)
                TriggerClientEvent("qb-advancedweather-ultra:client:NewsFlash", -1,
                    "Hurricane system has weakened and is moving away.")
            end
        end
    end
end)

-- High-frequency server tick: updates positions and sends interpolation payloads to clients
CreateThread(function()
    local TICK_MS = 500 -- 0.5s server tick for interpolation
    while true do
        local tickStart = os.time()

        -- update positions for systems and hurricanes
        for _, storm in ipairs(WeatherState.systems) do
            local rad = math.rad(storm.direction)
            storm.x = storm.x + math.cos(rad) * (storm.speed * (TICK_MS/1000))
            storm.y = storm.y + math.sin(rad) * (storm.speed * (TICK_MS/1000))
        end

        for _, h in ipairs(WeatherState.hurricanes) do
            local rad = math.rad(h.direction)
            h.x = h.x + math.cos(rad) * (h.speed * (TICK_MS/1000))
            h.y = h.y + math.sin(rad) * (h.speed * (TICK_MS/1000))
        end

        -- build lightweight interpolation payload per active system
        local payload = {
            timestamp = os.time(),
            tick_ms = TICK_MS,
            systems = {},
            hurricanes = {}
        }

        for _, s in ipairs(WeatherState.systems) do
            table.insert(payload.systems, {
                id = s.id,
                x = s.x,
                y = s.y,
                direction = s.direction,
                speed = s.speed,
                strength = s.strength,
                type = s.type
            })
        end

        for _, h in ipairs(WeatherState.hurricanes) do
            table.insert(payload.hurricanes, {
                id = h.id,
                x = h.x,
                y = h.y,
                direction = h.direction,
                speed = h.speed,
                strength = h.strength,
                expiresAt = h.expiresAt
            })
        end

        -- send to all clients
        TriggerClientEvent("qb-advancedweather-ultra:client:InterpolationUpdate", -1, payload)

        -- wait remaining time
        Wait(TICK_MS)
    end
end)

local function calculateBaseWeather(zone, coords)
    local climate = Config.Climates[zone]
    if not climate then
        return {
            weatherType = "CLEAR",
            intensity = 0.0,
            temp = 20.0,
            hurricane = false
        }
    end

    local temp = climate.baseTemp
    local rain = climate.rainChance or 0.0
    local storm = climate.stormChance or 0.0

    local seasonCfg = Config.Seasons[WeatherState.season or "summer"]
    if seasonCfg then
        temp = temp + (seasonCfg.tempBoost or 0.0)
        storm = storm + (seasonCfg.stormBoost or 0.0)
        rain = rain + (seasonCfg.rainBoost or 0.0)
    end

    local finalWeather = "CLEAR"
    local intensity = 0.0
    local hurricaneActive = false

    -- check proximity to storms & hurricanes
    local pos2 = vector2(coords.x, coords.y)

    for _, h in ipairs(WeatherState.hurricanes) do
        local dist = #(pos2 - vector2(h.x, h.y))
        if dist < 3000.0 then
            hurricaneActive = true
            finalWeather = "STORM"
            intensity = math.max(intensity, h.strength)
        end
    end

    if not hurricaneActive then
        for _, s in ipairs(WeatherState.systems) do
            local dist = #(pos2 - vector2(s.x, s.y))
            if dist < 2500.0 then
                finalWeather = "STORM"
                intensity = math.max(intensity, s.strength)
            end
        end
    end

    if finalWeather == "CLEAR" then
        if math.random() < storm then
            finalWeather = "STORM"
            intensity = math.random()
        elseif math.random() < rain then
            finalWeather = "RAIN"
            intensity = math.random()
        end
    end

    -- snow logic in winter for paleto / mountains
    if (WeatherState.season == "winter") and zone == "paleto" and finalWeather ~= "CLEAR" then
        finalWeather = "SNOW"
    end

    return {
        weatherType = finalWeather,
        intensity = intensity,
        temp = temp,
        hurricane = hurricaneActive
    }
end

exports("CalculateWeatherForZone", function(zone, coords)
    return calculateBaseWeather(zone, coords or vector3(0.0, 0.0, 0.0))
end)
