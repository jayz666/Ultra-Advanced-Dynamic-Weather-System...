
fx_version 'cerulean'
game 'gta5'

author 'ChatGPT'
description 'Ultra Advanced Dynamic Weather System for QB-Core'
version '2.0.0'

lua54 'yes'

shared_script 'config.lua'

server_scripts {
    'server/seasons.lua',
    'server/zones.lua',
    'server/systems.lua',
    'server/grid.lua',
    'server/newsflash.lua',
    'server/haarp.lua',
    'server/weather_core.lua'
}

client_scripts {
    'client/apply_weather.lua',
    'client/effects.lua',
    'client/radar.lua',
    'client/tv.lua',
    'client/items.lua'
}
