
Config = {}

-- Climate Zones
Config.Climates = {
    city = { baseTemp = 22, rainChance = 0.25, stormChance = 0.10 },
    sandy = { baseTemp = 32, rainChance = 0.05, stormChance = 0.02, dustChance = 0.15 },
    paleto = { baseTemp = 17, rainChance = 0.40, stormChance = 0.20 },
}

-- Seasons
Config.Seasons = {
    summer = { tempBoost = 8, stormBoost = -0.05, hurricaneChance = 0.10 },
    winter = { tempBoost = -10, stormBoost = 0.10, snowChance = 0.40 },
    autumn = { tempBoost = -2, stormBoost = 0.15 },
    spring = { tempBoost = 3, stormBoost = 0.15, rainBoost = 0.10 },
}

-- News Flash broadcast interval (seconds)
Config.NewsBroadcastInterval = 900 -- 15 minutes

-- Power grid behaviour
Config.Grid = {
    zones = { "city", "sandy", "paleto" },
    baseFailureChance = 0.02,         -- base chance of random failure
    stormFailureBonus = 0.20,         -- extra failure chance in storms
    hurricaneFailureBonus = 0.60,     -- extra failure chance in hurricanes
    outageDuration = { min = 300, max = 900 } -- seconds
}

-- Hurricane parameters
Config.Hurricanes = {
    enabled = true,
    baseChance = 0.02,        -- overall low chance
    minStrength = 0.6,
    maxStrength = 1.0,
    lifespan = { min = 1800, max = 3600 } -- seconds
}

-- Radar / TV / Phone labels
Config.WeatherNewsPrefix = "[WEATHER]"

-- Weather Channel / NewsFlash configuration
Config.DayNight = {
    -- Real-world seconds used to represent the daytime and nighttime portions of a full 24-hour cycle.
    -- Example below: day = 18 real minutes (18*60 = 1080s), night = 6 real minutes (6*60 = 360s) => day is longer.
    -- These control how fast the in-game timeOfDay advances relative to wall-clock time.
    dayLength = 18 * 60, -- seconds for the daytime portion
    nightLength = 6 * 60, -- seconds for the nighttime portion
    -- Optional: starting timeOfDay (0-24). Nil will default to 12 (noon).
    defaultStartHour = 12
}

-- Weather Channel / NewsFlash configuration
Config.WeatherChannel = {
    enabled = true,                 -- enable server->client Weather Channel broadcasts
    enhanced = true,                -- use enhanced UI + sound (client/tv.lua handles this)
    useTicker = true,               -- show ticker text on TV and small popup
    sound = {
        name = "FLASH",           -- sound name to play (client-side)
        set = "HUD_MINI_GAME_SOUNDSET" -- soundset
    },
    serverPrefix = Config.WeatherNewsPrefix, -- prefix applied by server messages
    allowCommandFromConsole = true  -- allow console to broadcast via command
}
